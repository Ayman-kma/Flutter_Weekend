// ignore_for_file: flutter_style_todos
import 'package:flutter/material.dart';
// ignore: unused_import
import 'package:tailwind_colors/tailwind_colors.dart';
// TODO: use Tailwind

/// Colors from Tailwind CSS (v3.0) - June 2022
///
/// https://tailwindcss.com/docs/customizing-colors

int _primaryColor = TW3Colors.violet.shade500.hashCode;
MaterialColor primarySwatch = MaterialColor(_primaryColor, <int, Color>{
  50: TW3Colors.violet.shade50 ?? TW3Colors.violet.shade100,
  100: TW3Colors.violet.shade100,
  200: TW3Colors.violet.shade200,
  300: TW3Colors.violet.shade300,
  400: TW3Colors.violet.shade400,
  500: Color(_primaryColor),
  600: TW3Colors.violet.shade600,
  700: TW3Colors.violet.shade700,
  800: TW3Colors.violet.shade800,
  900: TW3Colors.violet.shade900,
});

int _textColor = TW3Colors.neutral.shade500.hashCode;
MaterialColor textSwatch = MaterialColor(_textColor, <int, Color>{
  50: TW3Colors.neutral.shade50 ?? TW3Colors.neutral.shade100, // slate-100
  100: TW3Colors.neutral.shade100, // slate-100
  200: TW3Colors.neutral.shade200, // slate-200
  300: TW3Colors.neutral.shade300, // slate-300
  400: TW3Colors.neutral.shade400, // slate-400
  500: Color(_textColor), // slate-500
  600: TW3Colors.neutral.shade600, // slate-600
  700: TW3Colors.neutral.shade700, // slate-700
  800: TW3Colors.neutral.shade800, // slate-800
  900: TW3Colors.neutral.shade900, // slate-900
});

const Color errorColor = Color(0xFFDC2626); // red-600

final ColorScheme lightColorScheme = ColorScheme.light(
  primary: primarySwatch.shade500,
  secondary: primarySwatch.shade500,
  onSecondary: Colors.white,
  error: errorColor,
  background: TW3Colors.slate.shade200,
  onBackground: TW3Colors.slate.shade700,
  onSurface: TW3Colors.slate.shade700,
  surface: TW3Colors.slate.shade50 ?? TW3Colors.slate.shade100,
  surfaceVariant: Colors.white,
  shadow: TW3Colors.slate.shade900.withOpacity(.1),
);

final ColorScheme darkColorScheme = ColorScheme.dark(
  primary: primarySwatch.shade500,
  secondary: primarySwatch.shade500,
  onSecondary: Colors.white,
  error: errorColor,
  background: Colors.black,
  onBackground: TW3Colors.neutral.shade400,
  onSurface: TW3Colors.neutral.shade300,
  surface: TW3Colors.neutral.shade900,
  surfaceVariant: TW3Colors.neutral.shade800,
  shadow: TW3Colors.neutral.shade900.withOpacity(1),
);

final ThemeData lightTheme = ThemeData(
  colorScheme: lightColorScheme,
  fontFamily: 'Nunito',
  toggleableActiveColor: primarySwatch.shade500,
  textTheme: TextTheme(
    displayLarge: TextStyle(
      color: textSwatch.shade700,
      fontFamily: 'Nunito',
    ),
    displayMedium: TextStyle(
      color: textSwatch.shade600,
      fontFamily: 'Nunito',
    ),
    displaySmall: TextStyle(
      color: textSwatch.shade500,
      fontFamily: 'Nunito',
    ),
    headlineLarge: TextStyle(
      color: textSwatch.shade700,
      fontFamily: 'Nunito',
    ),
    headlineMedium: TextStyle(
      color: textSwatch.shade600,
      fontFamily: 'Nunito',
    ),
    headlineSmall: TextStyle(
      color: textSwatch.shade500,
      fontFamily: 'Nunito',
    ),
    titleLarge: TextStyle(
      color: textSwatch.shade700,
      fontFamily: 'Nunito',
    ),
    titleMedium: TextStyle(
      color: textSwatch.shade600,
      fontFamily: 'Nunito',
    ),
    titleSmall: TextStyle(
      color: textSwatch.shade500,
      fontFamily: 'Nunito',
    ),
    bodyLarge: TextStyle(
      color: textSwatch.shade700,
      fontFamily: 'Nunito',
    ),
    bodyMedium: TextStyle(
      color: textSwatch.shade600,
      fontFamily: 'Nunito',
    ),
    bodySmall: TextStyle(
      color: textSwatch.shade500,
      fontFamily: 'Nunito',
    ),
    labelLarge: TextStyle(
      color: textSwatch.shade700,
      fontFamily: 'Nunito',
    ),
    labelMedium: TextStyle(
      color: textSwatch.shade600,
      fontFamily: 'Nunito',
    ),
    labelSmall: TextStyle(
      color: textSwatch.shade500,
      fontFamily: 'Nunito',
    ),
  ),
);

final ThemeData darkTheme = lightTheme.copyWith(
  colorScheme: darkColorScheme,
  toggleableActiveColor: primarySwatch.shade500,
  textTheme: TextTheme(
    displayLarge: TextStyle(
      color: textSwatch.shade200,
      fontFamily: 'Nunito',
    ),
    displayMedium: TextStyle(
      color: textSwatch.shade300,
      fontFamily: 'Nunito',
    ),
    displaySmall: TextStyle(
      color: textSwatch.shade400,
      fontFamily: 'Nunito',
    ),
    headlineLarge: TextStyle(
      color: textSwatch.shade200,
      fontFamily: 'Nunito',
    ),
    headlineMedium: TextStyle(
      color: textSwatch.shade300,
      fontFamily: 'Nunito',
    ),
    headlineSmall: TextStyle(
      color: textSwatch.shade400,
      fontFamily: 'Nunito',
    ),
    titleLarge: TextStyle(
      color: textSwatch.shade200,
      fontFamily: 'Nunito',
    ),
    titleMedium: TextStyle(
      color: textSwatch.shade300,
      fontFamily: 'Nunito',
    ),
    titleSmall: TextStyle(
      color: textSwatch.shade400,
      fontFamily: 'Nunito',
    ),
    bodyLarge: TextStyle(
      color: textSwatch.shade200,
      fontFamily: 'Nunito',
    ),
    bodyMedium: TextStyle(
      color: textSwatch.shade300,
      fontFamily: 'Nunito',
    ),
    bodySmall: TextStyle(
      color: textSwatch.shade400,
      fontFamily: 'Nunito',
    ),
    labelLarge: TextStyle(
      color: textSwatch.shade200,
      fontFamily: 'Nunito',
    ),
    labelMedium: TextStyle(
      color: textSwatch.shade300,
      fontFamily: 'Nunito',
    ),
    labelSmall: TextStyle(
      color: textSwatch.shade400,
      fontFamily: 'Nunito',
    ),
  ),
);
