import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../states/theme_mode_state.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
 class CategorySection extends ConsumerWidget {
  const CategorySection({
    super.key,
    required this.title,
    required this.isPrimaryColor,
  });

  final String title;
  final bool isPrimaryColor;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ThemeModeState state = ref.watch(themeProvider);
    final TextTheme textTheme = isPrimaryColor
        ? Theme.of(context).primaryTextTheme
        : Theme.of(context).textTheme;

    return Card(
      elevation: 2,
      shadowColor: Theme.of(context).colorScheme.shadow,
        color: isPrimaryColor
          ? Theme.of(context).colorScheme.primary
          : Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(12))),
      child: InkWell(
          onTap: () => {},
          borderRadius: const BorderRadius.all(Radius.circular(12)),
          child: Container(
            padding: EdgeInsets.only(top: 8, bottom: 8, left: 12, right: 12),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  textAlign: TextAlign.center,
                  title,
                  style: textTheme.bodyMedium
                ),
              ],
            ),
          )),
    );
  }
}
