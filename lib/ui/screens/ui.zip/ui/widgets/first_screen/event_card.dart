import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class EventCard extends StatelessWidget {
  const EventCard(
      {super.key,
      required this.title,
      required this.content,
      required this.icon,
      required this.isPrimaryColor});

  final String title;
  final String content;
  final IconData icon;
  final bool isPrimaryColor;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = isPrimaryColor
        ? Theme.of(context).primaryTextTheme
        : Theme.of(context).textTheme;
    return Card(
      elevation: 2,
      shadowColor: Theme.of(context).colorScheme.shadow,
      color: isPrimaryColor
          ? Theme.of(context).colorScheme.primary
          : Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(12))),
      child: Padding(
        padding: const EdgeInsets.all(0.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Stack(
  children: <Widget>[
    Container(
      width: double.infinity,
      height: 216,
      child: ClipRRect(
  borderRadius: const BorderRadius.all(Radius.circular(12.0)),
  child: ShaderMask(
  shaderCallback: (rect) {
    return LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Colors.black, Colors.transparent],
    ).createShader(Rect.fromLTRB(0, rect.height/3, rect.width, rect.height));
  },
  blendMode: BlendMode.dstIn,
  child: Image.network(
                              'https://lh5.googleusercontent.com/p/AF1QipM0oMitmFw7ImS4SL595VT0oP6OmIOejWDG05UT=s1016-k-no',
                              fit: BoxFit.cover,
                            ),
),
      )
    ),
    Container(
      width: double.infinity,
      height: 216,
      
      // color: Colors.green,
      child: Align(
        alignment: Alignment.bottomLeft,
        child:Padding(
                  padding: const EdgeInsets.all(24.0),
          child: Text(
              "#FlutterWeekend",
              style: textTheme.headline5!.apply(fontWeightDelta: 2).copyWith(
                color: Colors.white,
                shadows: <Shadow>[
                  const Shadow(
                    offset: Offset(0, 2),
                    color: Color.fromARGB(255, 63, 29, 72),
                    blurRadius: 20
                  )

                ]
                ),
            ))),
    ),

  ],
),

            // const SizedBox(height: 10),

            // Text(
            //   tr(content),
            //   style: textTheme.bodyMedium,
            // ),
            // const Spacer(),
            // Icon(
            //   icon,
            //   size: 32,
            //   color: textTheme.bodyMedium!.color,
            // ),
          ],
        ),
      ),
    );
  }
}
