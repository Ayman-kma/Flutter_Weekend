import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:heroicons/heroicons.dart';
import 'package:ionicons/ionicons.dart';

import '../widgets/first_screen/theme_card.dart';
import '../widgets/header.dart';
import '../widgets/second_screen/grid_item.dart';
import '../widgets/second_screen/link_card.dart';
import '../widgets/second_screen/text_divider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
        color: Theme.of(context).colorScheme.background,
        child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            child: CustomScrollView(
              slivers: <Widget>[
                SliverAppBar(
                    expandedHeight: 200,
                    pinned: true,
                    backgroundColor: Theme.of(context).colorScheme.background,
                    flexibleSpace: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Container(
                          width: 200,
                          child: const FlexibleSpaceBar(
                            title: Header(text: 'settings'),
                          ),
                        ),
                      ],
                    )),
                SliverList(
                    // ignore: always_specify_types
                    delegate: SliverChildListDelegate([
                  GridView.count(
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      crossAxisCount: 3,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                      childAspectRatio: 1.75 / 1,
                      padding: EdgeInsets.zero,
                      children: const <ThemeCard>[
                        ThemeCard(
                          mode: ThemeMode.system,
                          icon: Ionicons.contrast_outline,
                        ),
                        ThemeCard(
                          mode: ThemeMode.light,
                          icon: Ionicons.sunny_outline,
                        ),
                        ThemeCard(
                          mode: ThemeMode.dark,
                          icon: Ionicons.moon_outline,
                        ),
                      ]),
                  const SizedBox(height: 8),
                  Card(
                    elevation: 2,
                    shadowColor: Theme.of(context).colorScheme.shadow,

                    /// Example: Many items have their own colors inside of the ThemData
                    /// You can overwrite them in [config/theme.dart].
                    color: Theme.of(context).colorScheme.surface,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(12))),
                    child: SwitchListTile(
                      onChanged: (bool newValue) {
                        /// Example: Change locale
                        /// The initial locale is automatically determined by the library.
                        /// Changing the locale like this will persist the selected locale.
                        showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: const Text('Coming Soon!'),
                                backgroundColor: Theme.of(context).colorScheme.surface,
                                      shape: const RoundedRectangleBorder(
                                        borderRadius: BorderRadius.all(Radius.circular(16)),
                                        ),
                              );
                            });
                      },
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(12))),
                      value: context.locale == const Locale('ar'),
                      title: Row(
                        children: <Widget>[
                          Icon(Ionicons.language_outline,
                              color: Theme.of(context).colorScheme.primary),
                          const SizedBox(width: 16),
                          Text(
                            tr('language_switch_title'),
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium!
                                .apply(fontWeightDelta: 2),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  LinkCard(
                      title: 'github_card_title',
                      icon: Ionicons.logo_github,
                      url: Uri.parse(
                          'https://github.com/Ayman-kma/Flutter_Weekend')),
                  const TextDivider(text: 'Team Members'),
                  GridView.count(
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 1,
                    childAspectRatio: 2 / 1.15,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                    shrinkWrap: true,
                    padding: EdgeInsets.zero,
                    children: const <GridItem>[
                      GridItem(
                        title: 'instagram_card_title',
                        // icon: HeroIcons.academicCap,
                        emoji: '🔵',
                      ),
                      GridItem(
                        title: 'twitter_card_title',
                        icon: Ionicons.logo_twitter,
                      ),
                      GridItem(
                        title: 'donate_card_title',
                        icon: Ionicons.heart_outline,
                      ),
                      GridItem(
                        title: 'website_card_title',
                        icon: Ionicons.desktop_outline,
                      ),
                    ],
                  ),
                  const TextDivider(text: 'packages_divider_title'),
                  GridView.count(
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 2,
                    childAspectRatio: 2 / 1.15,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                    shrinkWrap: true,
                    padding: EdgeInsets.zero,
                    children: const <GridItem>[
                      GridItem(
                        title: 'flutter_riverpod',
                        icon: Ionicons.leaf_outline,
                        version: '1.0.4',
                      ),
                      GridItem(
                        title: 'lints',
                        icon: Ionicons.code_slash_outline,

                        version: '2.0.1',
                      ),
                      GridItem(
                        title: 'path_provider',
                        icon: Ionicons.extension_puzzle_outline,
                        version: '2.0.11',
                      ),
                      GridItem(
                        title: 'flutter_displaymode',
                        icon: Ionicons.speedometer_outline,
                        version: '0.4.0',
                      ),
                      GridItem(
                        title: 'easy_localization',
                        icon: Ionicons.language_outline,
                        version: '3.0.1',
                      ),
                      GridItem(
                        title: 'hive',
                        icon: Ionicons.folder_open_outline,
                        version: '2.2.3',
                      ),
                      GridItem(
                        title: 'url_launcher',
                        icon: Ionicons.share_outline,
                        version: '6.1.5',
                      ),
                      GridItem(
                        title: 'ionicons',
                        icon: Ionicons.logo_ionic,
                        version: '0.2.1',
                      ),
                    ],
                  ),
                  const SizedBox(height: 36),
                ]))
              ],
            )));
  }
}
