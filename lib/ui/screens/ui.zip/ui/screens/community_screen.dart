import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:heroicons/heroicons.dart';
import 'package:ionicons/ionicons.dart';

import '../widgets/first_screen/event_card.dart';
import '../widgets/first_screen/theme_card.dart';
import '../widgets/header.dart';
import '../widgets/second_screen/grid_item.dart';
import '../widgets/second_screen/link_card.dart';
import '../widgets/second_screen/text_divider.dart';

class CommunityScreen extends StatelessWidget {
  const CommunityScreen({super.key});

  @override
  Widget build(BuildContext context) {
        final TextTheme textTheme = Theme.of(context).textTheme;
    return Material(
        color: Theme.of(context).colorScheme.background,
        child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 0),
            child: CustomScrollView(
              slivers: <Widget>[
                SliverAppBar(

                    expandedHeight: 200,
                    pinned: true,
                    backgroundColor: Theme.of(context).colorScheme.background,
                    flexibleSpace:FlexibleSpaceBar(
                
                            title: Header(text: 'Thakaa\' Community'),
                            background: ShaderMask(
  shaderCallback: (rect) {
    return LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Colors.black, Colors.transparent],
    ).createShader(Rect.fromLTRB(0, rect.height/3, rect.width, rect.height));
  },
  blendMode: BlendMode.dstIn,
  child: Image.network(
                              'https://lh5.googleusercontent.com/p/AF1QipM0oMitmFw7ImS4SL595VT0oP6OmIOejWDG05UT=s1016-k-no',
                              fit: BoxFit.cover,
                            ),
),

                    ),
                ),
                SliverList(
                    // ignore: always_specify_types
                    delegate: SliverChildListDelegate([

Card(
      elevation: 2,
      shadowColor: Theme.of(context).colorScheme.shadow,
      color: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(12))),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              "Description",
              style: textTheme.bodyLarge!.apply(fontWeightDelta: 2),
            ),
            const SizedBox(height: 10),
            Text(
              "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since it was first used to print the type of typeetting industry. Lore",
              style: textTheme.bodyMedium,
            ),
                          const SizedBox(height: 20),

          ],
        ),
      ),
    ),
                    
                  const SizedBox(height: 8),
                  LinkCard(
                      title: 'Get directions',
                      icon: Ionicons.locate,
                      url: Uri.parse('https://goo.gl/maps/YvuYQ5oBFTax43ZT8')),
                  const TextDivider(text: 'Upcoming Events'),
                  GridView.count(
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 1,
                    childAspectRatio: 2 / 1.15,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                    shrinkWrap: true,
                    padding: EdgeInsets.zero,
                    children:const <EventCard>[
                /// Example: it is good practice to put widgets in separate files.
                /// This way the screen files won't become too large and
                /// the code becomes more clear.
                EventCard(
                    title: 'localization_title',
                    content: 'localization_content',
                    icon: Ionicons.language_outline,
                    isPrimaryColor: true),

              ]
                  ),
                  const SizedBox(height: 36),
                  
                ]))
              ],
            )));
  }
}
