import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:ionicons/ionicons.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:location/location.dart';
import 'package:flutter_production_boilerplate_riverpod/auth_gate.dart';
import 'package:flutter_production_boilerplate_riverpod/ui/models/community.dart';
import 'package:flutter_production_boilerplate_riverpod/ui/models/package.dart';
import 'package:flutter_production_boilerplate_riverpod/ui/models/places.dart';
// import 'package:flutter_production_boilerplate_riverpod/ui/widgets/first_screen/package.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:ionicons/ionicons.dart';

import 'package:flutter_production_boilerplate_riverpod/ui/widgets/first_screen/category_section.dart';
import 'package:maps_toolkit/maps_toolkit.dart';
// import 'package:location/location.dart';


import '../widgets/first_screen/category_section.dart';
import '../widgets/first_screen/community_card.dart';
import '../widgets/first_screen/info_card.dart';
import '../widgets/first_screen/theme_card.dart';
import '../widgets/header.dart';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';

import '../widgets/first_screen/theme_card.dart';
import '../widgets/second_screen/grid_item.dart';
import '../widgets/second_screen/link_card.dart';
import '../widgets/second_screen/text_divider.dart';
import '../widgets/second_screen/package_text_divider.dart';
import 'community_screen.dart';

void showSnack(BuildContext context, bool inside) {
  if (inside) {
    WidgetsBinding.instance.addPostFrameCallback(
        (_) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text("You are inside the Community"),
              backgroundColor: Colors.green,
            )));
  }
  if (!inside) {
    WidgetsBinding.instance.addPostFrameCallback(
        (_) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text("You are outside the Community"),
              backgroundColor: Colors.red,
            )));
  }
}


CollectionReference eventData = FirebaseFirestore.instance.collection("Event");
CollectionReference placeData = FirebaseFirestore.instance.collection("Place");
CollectionReference communityData =
    FirebaseFirestore.instance.collection("Community");

CollectionReference packageData =
    FirebaseFirestore.instance.collection("Pacage");

final SelectCategoryProvider = StateProvider<int>((ref) {
  return -1;
});

final getEvent =
    StreamProvider.autoDispose<QuerySnapshot>((ref) => eventData.snapshots());

final getPlace =
    StreamProvider.autoDispose<QuerySnapshot>((ref) => placeData.snapshots());
final getCommunity = StreamProvider.autoDispose<QuerySnapshot>(
    (ref) => communityData.snapshots());

final getPackageData =
    StreamProvider.autoDispose<QuerySnapshot>((ref) => packageData.snapshots());



class FirstScreen extends ConsumerStatefulWidget {
  const FirstScreen({super.key});
  static bool callIt = false;

  @override
  ConsumerState<FirstScreen> createState() => _FirstScreenState();
}


class _FirstScreenState extends ConsumerState<FirstScreen> {
  Location location = new Location();

  bool? _serviceEnabled;

  PermissionStatus? _permissionGranted;

  LocationData? _locationData;
  String curentLocationDD = "123";
  @override
  void initState() {
    super.initState();

    setup();
  }

  void setup() async {
    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled!) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled!) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }
    _locationData = await location.getLocation();

    location.enableBackgroundMode(enable: true);
    location.onLocationChanged.listen((LocationData currentLocation) {
      setState(() {
        AuthGate.long = currentLocation!.longitude.toString();
        AuthGate.lat = currentLocation!.latitude.toString();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    var eventData = ref.watch(getEvent);
    var placeData = ref.watch(getPlace);
    var communityData = ref.watch(getCommunity);
    var packageData = ref.watch(getPackageData);
    print("============");
    print("============");
    print("============");
    print("============");
    print("============");
    print("============");
    print("============");
    print("============");
    print(AuthGate.long);
    // LatLng point =
        // LatLng(double.parse(AuthGate.lat), double.parse(AuthGate.long));
    // LatLng point = LatLng(26.311641, 50.224461);
    // LatLng point = LatLng(26.311648, 50.224435);
    // print("lat ${double.parse(AuthGate.lat)}");
    // print("long ${double.parse(AuthGate.long)}");
    // List<LatLng> polygonPoints = [

    //   LatLng(26.311694, 50.224484),
    //   LatLng(26.311624, 50.224504),
    //   LatLng(26.311613, 50.224398),
    //   LatLng(26.311676, 50.224384),

    // ];
    // bool geodesic = true;
    // bool inside = PolygonUtil.containsLocation(point, polygonPoints, geodesic);
    // if (FirstScreen.callIt != inside) {
    //   showSnack(context, inside);
    // }

    // FirstScreen.callIt = inside;
    return Material(
      color: Theme.of(context).colorScheme.background,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18),
        child: CustomScrollView(
          slivers: <Widget>[
            SliverAppBar(
              expandedHeight: 200,
              pinned: true,
              backgroundColor: Theme.of(context).colorScheme.background,
              flexibleSpace: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Container(
                    width: 200,
                    child: const FlexibleSpaceBar(
                      title: Header(text: 'Home              '),
                    ),
                  ),
                ],
              )
            ),
            SliverList(
              // ignore: always_specify_types
              delegate: SliverChildListDelegate([
                  const PackageTextDivider(text: '🔥 Spark Package'),
                  GridView.count(
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 2,
                    childAspectRatio: 2 / 1.15,
                    // crossAxisSpacing: 0,
                    mainAxisSpacing: 0,
                    shrinkWrap: true,
                    padding: EdgeInsets.zero,
                    children: <GridItem>[
                      GridItem(
                        title: 'STC eSIM',
                        emoji: '📱',
                        version: '200 mins',
                      ),
                      GridItem(
                        title: '5G Internet',
                        emoji: '🌐',
                        version: '20 GB (1GB/Day)',
                      ),
                      GridItem(
                        title: 'UBER 10% OFF',
                        emoji: '🚕',
                        version: 'Total 100SAR',
                      ),
                      GridItem(
                        title: 'Alshaya Group',
                        emoji: '🛍️',
                        version: '15% Discount',
                      ),
                    ],
                  ),
                  const SizedBox(height: 36),
            /// Example: Good way to add space between items without using Paddings
            const SizedBox(height: 8),

            const SizedBox(height: 8),
            Header(text: ' Nearby Communities'),
            const SizedBox(height: 8),
            GridView.count(
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              crossAxisCount: 1,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio: 12 / 5.5,
              padding: EdgeInsets.zero,
              children: const <CommunityCard>[
                /// Example: it is good practice to put widgets in separate files.
                /// This way the screen files won't become too large and
                /// the code becomes more clear.
                CommunityCard(
                    title: 'localization_title',
                    content: 'localization_content',
                    icon: Ionicons.language_outline,
                    isPrimaryColor: false),
              ],
            ),
            const SizedBox(height: 36),

          ]
)
            ),
            
          ],
        )
      )
    );
  }
}




class PlaceItem extends StatelessWidget {
  String imageLink;
  String placeName;
  PlaceItem({
    required this.imageLink,
    required this.placeName,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 20),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: Theme.of(context).colorScheme.primary),
      height: 130,
      width: 300,
      child: Row(
        children: [
          Container(
            width: 100,
            child: Image.network(imageLink, fit: BoxFit.cover),
          ),
          SizedBox(
            width: 10,
          ),
          Text(
            placeName,
            style: TextStyle(fontSize: 30, color: Colors.white),
          ),
        ],
      ),
    );
  }
}

class CategoryItem extends StatelessWidget {
  String imageLink;
  String name;
  String description;
  CategoryItem({
    required this.imageLink,
    required this.name,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 400,
      margin: EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        color: Theme.of(context).colorScheme.primary,
      ),
      height: 200,
      child: Row(
        children: [
          Container(
            width: 150,
            child: Image.network(imageLink, fit: BoxFit.fill),
          ),
          SizedBox(
            width: 20,
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Text(
                name,
                style: TextStyle(fontSize: 30, color: Colors.white),
              ),
              Text(
                description,
                style: TextStyle(fontSize: 30, color: Colors.white),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
