// ignore_for_file: public_member_api_docs, sort_constructors_first
class geoLocation {
  String Lat;
  String Long;
  geoLocation({
    required this.Lat,
    required this.Long,
  });


}
